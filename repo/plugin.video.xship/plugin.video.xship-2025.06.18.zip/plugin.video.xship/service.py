
# 2022-10-09
# edit 2025-06-15

import sys, os
import requests
from xbmcaddon import Addon
from resources.lib.tools import logger
from resources.lib.requestHandler import cRequestHandler

is_python2 = sys.version_info.major == 2
if is_python2:
	from xbmc import translatePath
	from urlparse import urlparse
else:
	from xbmcvfs import translatePath
	from urllib.parse import urlparse

addonInfo = Addon().getAddonInfo
addonPath = translatePath(addonInfo('path'))
addonVersion = addonInfo('version')
setSetting = Addon().setSetting
_getSetting = Addon().getSetting

def getSetting(Name, default=''):
	result = _getSetting(Name)
	if result: return result
	else: return default

# Html Cache beim KodiStart loeschen
def delHtmlCache():
	try:
		# from resources.lib.requestHandler import cRequestHandler
		from time import time
		deltaDay = int(getSetting('cacheDeltaDay', 3))
		deltaTime = 60*60*24*deltaDay # Tage
		currentTime = int(time())
		# einmalig
		if getSetting('delHtmlCache') == 'true':
			cRequestHandler('').clearCache()
			setSetting('lastdelhtml', str(currentTime))
			setSetting('delHtmlCache', 'false')
		# alle x Tage
		elif currentTime >= int(getSetting('lastdelhtml', 0)) + deltaTime:
			cRequestHandler('').clearCache()
			setSetting('lastdelhtml', str(currentTime))
	except: pass

# Scraper(Seiten) ein- / ausschalten
#  [(providername, domainname), ...]	 providername identisch mit dateiname
def _getPluginData():
	from os import path, listdir
	sPluginFolder = path.join(addonPath, 'scrapers', 'scrapers_source', 'de')
	sys.path.append(sPluginFolder)
	items = listdir(sPluginFolder)
	aFileNames=[]
	aPluginsData = []
	for sItemName in items:
		if sItemName.endswith('.py'): aFileNames.append(sItemName[:-3])
	for fileName in aFileNames:
		if fileName ==  '__init__': continue
		try:
			plugin = __import__(fileName, globals(), locals())
			# print(plugin.SITE_DOMAIN +'  '+ plugin.SITE_IDENTIFIER)
			aPluginsData.append({'domain': plugin.SITE_DOMAIN, 'provider': plugin.SITE_IDENTIFIER})
		except:
			pass
	return aPluginsData


def check_domains():
	domains = _getPluginData()
	import threading
	threads = []
	try:
		for item in domains:
			_domain = item['domain']
			_provider = item['provider']
			t = threading.Thread(target=_checkdomain, args=(_domain, _provider))
			threads += [t]
			t.start()
	except:
		pass
	for count, t in enumerate(threads):
		t.join()


def _checkdomain(_domain, _provider):
	try:
		requests.packages.urllib3.disable_warnings()  # weil verify = False - ansonst Fehlermeldungen im kodi log
		check=None
		status_code=None
		if _provider == 'vavoo':
			setSetting('provider.' + _provider + '.check', 'true')
			return
		domain = getSetting('provider.'+ _provider +'.domain', _domain)
		base_link = 'https://' + domain
		try:
			UA=cRequestHandler.RandomUA()
			headers = {
				"referer": base_link,
				"user-agent": UA,
			}
			r = requests.head(base_link, verify=False, headers=headers)
			status_code = r.status_code
			if 300 <= status_code <= 400:
				url = r.headers['Location']
				domain = urlparse(url).hostname
				check = 'true'
			elif status_code == 200:
				domain = urlparse(base_link).hostname
				check = 'true'
			else:
				check = 'false'
		except:
			check = 'false'
			#pass
		finally:
			wrongDomain = 'site-maps.cc', 'www.drei.at', 'notice.cuii.info'
			if domain in wrongDomain:
				setSetting('provider.' + _provider + '.check', '')
				setSetting('provider.' + _provider + '.domain', '')
			else:
				setSetting('provider.' + _provider + '.check', check)
				setSetting('provider.' + _provider + '.domain', domain)
			logger.info(' -> [service]: Provider: %s / Statuscode: %s / Domain: %s, Check: %s' % (_provider, status_code, domain, check))
	except: pass


# Download Helper File  - code neutral fÃ¼r xship und xstream (py3)
def download_help():
	def creation_date(path_to_file):
		import os
		import platform
		"""
		Try to get the date that a file was created, falling back to when it was
		last modified if that isn't possible.
		See http://stackoverflow.com/a/39501288/1709587 for explanation.
		"""
		if platform.system() == 'Windows':
			# return os.path.getctime(path_to_file)
			return os.path.getmtime(path_to_file)   # edit kasi
		else:
			status = os.stat(path_to_file)
			try:
				return status.st_birthtime
			except AttributeError:
				# We're probably on Linux. No easy way to get creation dates here,
				# so we'll settle for when its content was last modified.
				return status.st_mtime

	def noInternet():
		from xbmcgui import Dialog
		from xbmc import executebuiltin
		Dialog().ok('ERROR', '[COLOR red] Problem mit der Internet Verbindung ? [/COLOR]')
		executebuiltin("Dialog.Close(all)")
		executebuiltin("ActivateWindow(Home)")

	import stat
	from os import path, chmod
	from time import time
	from resources.lib.utils import download_url, unzip
	from xbmcvfs import translatePath, delete
	from xbmcaddon import Addon

	try:
		addonInfo = Addon().getAddonInfo
		addonPath = translatePath(addonInfo('path'))  # 'C:\\Program Files\\Kodi21\\portable_data\\addons\\plugin.video.xship\\'
		diffTime = 60*60*8 # 8 Stunden
		currentTime = int(time())
		url = 'https://michaz1988.github.io/logos/logo_aktuell.jpg'
		contr = translatePath(path.join(addonPath, 'resources', 'lib', 'help.py'))
		dest = translatePath(path.join(addonPath, 'resources', 'lib'))
		src = translatePath(path.join('special://temp', url.split('/')[-1]))

		if not path.exists(contr) or int(creation_date(contr)) <= currentTime - diffTime:
			try:
				download_url(url, src, dp=False) # dp - progressDialog nicht anzeigen
				if path.exists(contr):
					chmod(contr, stat.S_IWRITE)
					delete(contr)
				if path.exists(src):
					unzip(src, dest, folder=None)
					delete(src)
				else: noInternet()

				if path.exists(contr):
					from resources.lib.help import starter2
					starter2()
			except:
				noInternet()
		else:
			from resources.lib.help import starter2
			starter2()
	except: exit()

# kasi - Code fÃ¼r Zwangsupdate
def checkVersion():
	try:
		import requests, re, xbmc
		from xbmcaddon import Addon
		addonVersion = Addon().getAddonInfo('version')
		addonId = Addon().getAddonInfo('id')
		url = 'https://raw.githubusercontent.com/watchone/watchone.github.io/refs/heads/repo/plugin.video.xship/addon.xml'
		url2 = 'https://github.com/watchone/watchone.github.io/raw/refs/heads/repo/plugin.video.xship/%s'

		r = requests.get(url)
		if r.status_code != 200 : return
		remoteVersion = re.findall('version="([^"]+)', str(r.content))[1]
		if addonVersion == remoteVersion: return False

		from os import path
		from xbmcvfs import delete
		from resources.lib.utils import download_url, unzip, remove_dir
		addonPath = translatePath('special://home/addons/%s') % addonId
		zipfile = '%s-%s.zip' % (addonId, remoteVersion)
		url =  url2 % zipfile
		src = translatePath(path.join('special://temp', url.split('/')[-1]))
		dest = translatePath('special://temp')
		download_url(url, src, dp=True)  # dp - progressDialog nicht anzeigen
		unzip(src, dest, folder=None)
		vav = open(translatePath('special://home/addons/plugin.video.xship/scrapers/scrapers_source/de/vavoo.py')).read()
		with open(translatePath('special://temp/plugin.video.xship/scrapers/scrapers_source/de/vavoo.py'), "w") as m:
			m.write(vav)
		serv = open(os.path.abspath(__file__)).read()
		with open(translatePath('special://temp/plugin.video.xship/service.py'), "w") as m:
			m.write(serv)
		k = []
		for a in open(translatePath('special://temp/plugin.video.xship/addon.xml')).readlines():
			if "repository.xship" in a: continue
			k.append(a)
		with open(translatePath('special://temp/plugin.video.xship/addon.xml'), "w") as u:
			u.write("".join(k))
		delete(src)
		remove_dir(addonPath)
		os.rename(os.path.join(dest, addonId), addonPath)
		from xbmc import executebuiltin, getInfoLabel
		# executebuiltin("UpdateLocalAddons()") # kasi - ist das nÃ¶tig?
		profil = getInfoLabel('System.ProfileName')
		if profil: executebuiltin('LoadProfile(' + profil + ',prompt)')
	except:
		pass


def main():
	try:
		import xbmc
		if not xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
			xbmc.executebuiltin('InstallAddon(inputstream.adaptive)')
			xbmc.executebuiltin('SendClick(11)')
		xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
		isNewVersion = checkVersion()
		if not isNewVersion:  # False -> nur weitermachen weil kein reload Profil
			download_help()
			from os import path
			contr = translatePath(path.join(addonPath, 'resources', 'lib', 'help.py'))
			if path.exists(contr):
				# ab hier die restlichen Aufrufe
				check_domains()
				delHtmlCache()
			else:
				xbmc.executebuiltin('Quit')
				exit()
			if xbmc.getCondVisibility('Window.IsActive(busydialognocancel)') == 1:
				xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
	except:
		exit()

if __name__ == "__main__":
	main()