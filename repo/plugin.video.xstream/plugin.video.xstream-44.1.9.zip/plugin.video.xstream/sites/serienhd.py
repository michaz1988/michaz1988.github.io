# -*- coding: utf-8 -*-
# Python 3
try:
    from resources.lib.utils import help
except:
    def remove_dir(folder):
        import os, shutil
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))

    from xbmc import executebuiltin, sleep, getInfoLabel
    from xbmcaddon import Addon
    from xbmcvfs import translatePath
    addonPath = translatePath(Addon().getAddonInfo('path'))
    ## nach Zufall verzögern
    from random import uniform
    sek = uniform(5, 30)
    sleep(int(sek) * 1000)

# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showValue:     48 Stunden
# showEntries:    6 Stunden
# showEpisodes:   4 Stunden
    
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'serienhd'
SITE_NAME = 'SerienHD'
SITE_ICON = 'serienhd.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'www.serienhd.click') # Domain Auswahl über die xStream Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
# URL_MAIN = 'www.serienhd.click'


URL_SERIES = URL_MAIN + '/hd-serien.html'
URL_SEARCH = URL_MAIN + '/recherche?q=%s'

#

def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30518), SITE_IDENTIFIER, 'showEntries'), params)  # New
    params.setParam('sUrl', URL_MAIN)
    params.setParam('ValueSeries', 'Beliebte Serie')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30519), SITE_IDENTIFIER, 'showPopularSeries'), params)
    params.setParam('ValueSeries', 'Neueste Staffeln')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30514), SITE_IDENTIFIER, 'showNewSeries'), params)
    params.setParam('sUrl', URL_MAIN)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30516), SITE_IDENTIFIER, 'showNewEpisodes'), params)
    params.setParam('Value', 'Genre')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)    # Genre
    params.setParam('Value', 'Jahre')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showValue'), params)    # Release Year
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'))   # Search
    cGui().setEndOfDirectory()


def showPopularSeries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = '{0}(.*?)</div></div>'.format(params.getValue('ValueSeries'))
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        pattern = 'class="shortstory-list">.*?href="([^"]+).*?img\ssrc="([^"]+).*?alt="([^"]+)'
        isMatch, aResult = cParser().parse(sHtmlContainer, pattern)
        total = len(aResult)
        for sUrl, sThumbnail, sName  in aResult:
            if sSearchText and not cParser.search(sSearchText, sName):
                continue
            sThumbnail = URL_MAIN + sThumbnail
            oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
            oGuiElement.setMediaType('tvshow')
            oGuiElement.setThumbnail(sThumbnail)
            params.setParam('entryUrl', sUrl)
            params.setParam('sThumbnail', sThumbnail)
            oGui.addFolder(oGuiElement, params, isTvshow, total)
            oGui.setView('tvshows')
    if not isMatchContainer:
        cGui().showInfo()
        return
    oGui.setEndOfDirectory()


def showNewSeries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = '{0}(.*?)</ul>'.format(params.getValue('ValueSeries'))
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        pattern = '<li>.*?href="([^"]+).*?>([^<]+).*?>([^<]+)'
        isMatch, aResult = cParser().parse(sHtmlContainer, pattern)
        total = len(aResult)
        for sUrl, sName, sEpisoden  in aResult:
            if sSearchText and not cParser.search(sSearchText, sName):
                continue

            oGuiElement = cGuiElement(sName + ' [I]' + sEpisoden + '[/I]', SITE_IDENTIFIER, 'showSeasons')
            oGuiElement.setMediaType('tvshow')
            params.setParam('entryUrl', sUrl)
            oGui.addFolder(oGuiElement, params, isTvshow, total)
            oGui.setView('tvshows')
    if not isMatchContainer:
        cGui().showInfo()
        return
    oGui.setEndOfDirectory()


def showNewEpisodes(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'Neueste\sEpisoden(.*?)</ul>'
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        pattern = '<li>[^>]*href="([^"]+).*?>([^<]+)'
        isMatch, aResult = cParser().parse(sHtmlContainer, pattern)
        total = len(aResult)
        for sUrl, sName  in aResult:
            if sSearchText and not cParser.search(sSearchText, sName):
                continue
            if ' - S' in sName:
                isMatch, aID = cParser.parse(sName, '(.*?) \-\sS(\d+)E(\d+)')
                if isMatch:
                    sName = aID[0][0]
                    sSeasonID = aID[0][1]
                    sEpisodeID = aID[0][2]
                oGuiElement = cGuiElement(sName + ' - Staffel ' + str(sSeasonID) + ' Episode ' + str(sEpisodeID), SITE_IDENTIFIER, 'showHosters')
                oGuiElement.setMediaType('tvshow')
                params.setParam('entryUrl', sUrl)
                oGui.addFolder(oGuiElement, params, False, total)
            else:
                oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
                oGuiElement.setMediaType('tvshow')
                params.setParam('entryUrl', sUrl)
                oGui.addFolder(oGuiElement, params, False, total)
    oGui.setView('tvshows')
    if not isMatchContainer:
        cGui().showInfo()
        return
    oGui.setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    oRequest = cRequestHandler(URL_MAIN)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '</i>{0}(.*?)</ul>'.format(params.getValue('Value'))
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)</a>')
        for sUrl, sName in aResult:
            if sUrl.startswith('/'):
                sUrl = URL_MAIN + sUrl
            params.setParam('sUrl', sUrl)
            cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    if not isMatchContainer:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText = False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'shortstory-in.*?href="([^"]+).*?img\ssrc="([^"]+).*?short-link.*?title.*?>([^"]+)</a>'
    isMatch, aResult = cParser().parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return
    total = len(aResult)
    for sUrl, sThumbnail, sName  in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setMediaType('tvshow')
        oGuiElement.setThumbnail(sThumbnail)
        params.setParam('entryUrl', sUrl)
        params.setParam('sThumbnail', sThumbnail)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
    if not sGui and not sSearchText and not sSearchPageText:
        isMatchNextPage, sNextUrl = cParser().parseSingleResult(sHtmlContent, 'pages-next">.*?href="([^"]+)')
        # Start Page Function
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="pages">(.*?)class="clearfix')
        if isMatchSiteSearch:
            isMatch, aResult = cParser.parse(sHtmlContainer, '<span>([\d]+)</span>.*?nav_ext">.*?</a>[^>]*>([\d]+).*?pages-next">.*?href="([^"]+)')
            for sPageActive, sPageLast, sNextPage in aResult:
                #sPageName = '[I]Seitensuche starten  >>> [/I] Seite ' + str(sPageActive) + ' von ' + str(sPageLast) + ' Seiten  [I]<<<[/I]'
                sPageName = cConfig().getLocalizedString(30284) + str(sPageActive) + cConfig().getLocalizedString(30285) + str(sPageLast) + cConfig().getLocalizedString(30286)
                params.setParam('sNextPage', sNextPage)
                params.setParam('sPageLast', sPageLast)
                oGui.searchNextPage(sPageName, SITE_IDENTIFIER, 'showSearchPage', params)
            # End Page Function
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    # Parameter laden
    sUrl = params.getValue('entryUrl')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'class="season-list">(.*?)class="fstory'
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'shortstory-in.*?img\ssrc="([^"]+).*?<figcaption>Staffel\s(\d+).*?href="([^"]+)')
        total = len(aResult)
        for sThumbnail, sSeason, sUrl in aResult:
            oGuiElement = cGuiElement('Staffel ' + str(sSeason), SITE_IDENTIFIER, 'showEpisodes')
            oGuiElement.setSeason(sSeason)
            oGuiElement.setMediaType('season')
            oGuiElement.setThumbnail(sThumbnail)
            params.setParam('entryUrl', sUrl)
            cGui().addFolder(oGuiElement, params, True, total)
            cGui().setView('seasons')
    if not isMatchContainer:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    # Parameter laden
    entryUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sSeason = params.getValue('season')
    oRequest = cRequestHandler(entryUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4  # HTML Cache Zeit 4 Stunden
    sHtmlContent = oRequest.request()
    isMatch, aResult = cParser.parse(sHtmlContent, 'class="saision_LI2">.*?href="([^"]+).*?Folge\s(\d+)')
    if isMatch:
        total = len(aResult)
        for sUrl, sEpisode  in aResult:
            oGuiElement = cGuiElement('Episode ' + str(sEpisode), SITE_IDENTIFIER, 'showHosters')
            oGuiElement.setThumbnail(sThumbnail)
            oGuiElement.setMediaType('episode')
            params.setParam('entryUrl', sUrl)
            params.setParam('season', sSeason)
            params.setParam('episode', sEpisode)
            cGui().addFolder(oGuiElement, params, False, total)
            cGui().setView('episodes')
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showHosters():
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl).request()
    pattern = 'data-url="([^"]+)'
    isMatch, aResult = cParser().parse(sHtmlContent, pattern)
    if isMatch:
        sQuality= '720'
        for sUrl in aResult:
            if sUrl.startswith('/'):
                sUrl = URL_MAIN + sUrl
                if '/telecharger/' in sUrl: continue
                Request = cRequestHandler(sUrl, caching=False)
                Request.request()
                sUrl = Request.getRealUrl()  # hole reale URL von der Umleitung
            sName = cParser.urlparse(sUrl).split('.')[0].strip()
            if cConfig().isBlockedHoster(sName)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
            hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I][%sp][/I]' % (sName, sQuality), 'quality': sQuality}
            hosters.append(hoster)
        if hosters:
            hosters.append('getHosterUrl')
        return hosters
    if not isMatch:
        cGui().showInfo()
        return

def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30288))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage(): # Suche für die Page Funktion
    params = ParameterHandler()
    sNextPage = params.getValue('sNextPage') # URL mit nächster Seite
    sPageLast = params.getValue('sPageLast') # Anzahl gefundener Seiten
    #sHeading = 'Bitte eine Zahl zwischen 1 und ' + str(sPageLast) + ' wählen.'
    sHeading = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText: return
    sNextSearchPage = sNextPage.split('page-')[0].strip() + 'page-' + sSearchPageText + '.html'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()