# -*- coding: utf-8 -*-
# Python 3
# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showValue:     48 Stunden
# showEntries:    6 Stunden
# showEpisodes:   4 Stunden

try:
    from resources.lib.utils import help
except:
    def remove_dir(folder):
        import os, shutil
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))

    from xbmc import executebuiltin, sleep, getInfoLabel
    from xbmcaddon import Addon
    from xbmcvfs import translatePath
    addonPath = translatePath(Addon().getAddonInfo('path'))
    ## nach Zufall verzögern
    from random import uniform
    sek = uniform(5, 30)
    sleep(int(sek) * 1000)

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'serien-stream'
SITE_NAME = 'Serien-Stream'
SITE_ICON = 'serien-stream.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'www.serien-stream.cc') # Domain Auswahl über die xStream Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
# URL_MAIN = 'https://www.serien-stream.cc'


URL_SERIES = URL_MAIN + '/serien'
URL_SEARCH = URL_MAIN + '/recherche?_token=jtVkMD6nTD1VurjrwSKR9L2vAjyLjg1xWDKHLLLz&q=%s'

#

def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_MAIN)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30518), SITE_IDENTIFIER, 'showEntries'), params)  # New
    params.setParam('ValueSeries', 'Beliebte Serie')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30519), SITE_IDENTIFIER, 'showValueSeries'), params)
    params.setParam('ValueSeries', 'Neueste Serien')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30514), SITE_IDENTIFIER, 'showValueSeries'), params)
    params.setParam('sUrl', URL_MAIN)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30516), SITE_IDENTIFIER, 'showNewEpisodes'), params)
    params.setParam('Value', 'Genre')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)    # Genre
    params.setParam('Value', 'Jahre')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showValue'), params)    # Release Year
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'))   # Search
    cGui().setEndOfDirectory()


def showValueSeries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = '{0}(.*?)</a>[^>]*</div>'.format(params.getValue('ValueSeries'))
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        pattern = 'side.*?href="([^"]+).*?img\ssrc="([^"]+).*?alt="([^"]+)'
        isMatch, aResult = cParser().parse(sHtmlContainer, pattern)
        total = len(aResult)
        for sUrl, sThumbnail, sName  in aResult:
            if sSearchText and not cParser.search(sSearchText, sName):
                continue
            sThumbnail = URL_MAIN + sThumbnail
            oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
            oGuiElement.setMediaType('tvshow')
            oGuiElement.setThumbnail(sThumbnail)
            params.setParam('entryUrl', sUrl)
            params.setParam('sThumbnail', sThumbnail)
            oGui.addFolder(oGuiElement, params, isTvshow, total)
            oGui.setView('tvshows')
    if not isMatchContainer:
        cGui().showInfo()
        return
    oGui.setEndOfDirectory()


def showNewEpisodes(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'Neueste\sEpisoden(.*?)</a>[^>]*</div>'
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        pattern = 'top-item".*?href="([^"]+).*?title1">([^<]+).*?S.*?(\d+).*?(\d+)'
        isMatch, aResult = cParser().parse(sHtmlContainer, pattern)
        total = len(aResult)
        for sUrl, sName, sSeason, sEpisode  in aResult:
            if sSearchText and not cParser.search(sSearchText, sName):
                continue
            oGuiElement = cGuiElement(sName + ' - Staffel ' + str(sSeason) + ' Episode ' + str(sEpisode), SITE_IDENTIFIER, 'showHosters')
            oGuiElement.setMediaType('tvshow')
            params.setParam('entryUrl', sUrl)
            oGui.addFolder(oGuiElement, params, False, total)
            oGui.setView('tvshows')
    if not isMatchContainer:
        cGui().showInfo()
        return
    oGui.setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    oRequest = cRequestHandler(URL_MAIN)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '>{0}(.*?)</ul>'.format(params.getValue('Value'))
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)')
        for sUrl, sName in aResult:
            if sUrl.startswith('/'):
                sUrl = URL_MAIN + sUrl
            params.setParam('sUrl', sUrl)
            cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    if not isMatchContainer:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText = False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'class="short\sclearfix\swith-mask">.*?img\ssrc="([^"]+).*?alt="([^"]+).*?href="([^"]+).*?'
    isMatch, aResult = cParser().parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return
    total = len(aResult)
    for sThumbnail, sName, sUrl in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        sThumbnail = URL_MAIN + sThumbnail
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setMediaType('tvshow')
        oGuiElement.setThumbnail(sThumbnail)
        params.setParam('entryUrl', sUrl)
        params.setParam('sThumbnail', sThumbnail)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
    if not sGui and not sSearchText and not sSearchPageText:
        isMatchNextPage, sNextUrl = cParser().parseSingleResult(sHtmlContent, 'class="pnext">.*?href="([^"]+)')
        # Start Page Function
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="pagi-nav(.*?)</main>')
        if isMatchSiteSearch:
            isMatch, aResult = cParser.parse(sHtmlContainer, '<span>([\d]+)</span>.*?nav_ext">.*?</a>[^>]*>([\d]+).*?class="pnext">.*?href="([^"]+)')
            for sPageActive, sPageLast, sNextPage in aResult:
                #sPageName = '[I]Seitensuche starten  >>> [/I] Seite ' + str(sPageActive) + ' von ' + str(sPageLast) + ' Seiten  [I]<<<[/I]'
                sPageName = cConfig().getLocalizedString(30284) + str(sPageActive) + cConfig().getLocalizedString(30285) + str(sPageLast) + cConfig().getLocalizedString(30286)
                sNextPage = URL_MAIN + sNextPage
                params.setParam('sNextPage', sNextPage)
                params.setParam('sPageLast', sPageLast)
                oGui.searchNextPage(sPageName, SITE_IDENTIFIER, 'showSearchPage', params)
            # End Page Function
        if isMatchNextPage:
            sNextUrl = URL_MAIN + sNextUrl
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    # Parameter laden
    sUrl = params.getValue('entryUrl')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'Alle\sStaffeln(.*?)<!'
    isMatchContainer, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatchContainer:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'img\ssrc="([^"]+).*?href="([^"]+).*?title">.*?(\d+)')
        total = len(aResult)
        for sThumbnail, sUrl, sSeason in aResult:
            sThumbnail = URL_MAIN + sThumbnail
            oGuiElement = cGuiElement('Staffel ' + str(sSeason), SITE_IDENTIFIER, 'showEpisodes')
            oGuiElement.setSeason(sSeason)
            oGuiElement.setMediaType('season')
            oGuiElement.setThumbnail(sThumbnail)
            params.setParam('entryUrl', sUrl)
            cGui().addFolder(oGuiElement, params, True, total)
            cGui().setView('seasons')
    if not isMatchContainer:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    # Parameter laden
    entryUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sSeason = params.getValue('season')
    oRequest = cRequestHandler(entryUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4  # HTML Cache Zeit 4 Stunden
    sHtmlContent = oRequest.request()
    isMatch, aResult = cParser.parse(sHtmlContent, 'folge\s(\d+).*?href="([^"]+)')
    if isMatch:
        total = len(aResult)
        for sEpisode, sUrl in aResult:
            oGuiElement = cGuiElement('Episode ' + str(sEpisode), SITE_IDENTIFIER, 'showHosters')
            oGuiElement.setThumbnail(sThumbnail)
            oGuiElement.setMediaType('episode')
            params.setParam('entryUrl', sUrl)
            params.setParam('season', sSeason)
            params.setParam('episode', sEpisode)
            cGui().addFolder(oGuiElement, params, False, total)
            cGui().setView('episodes')
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showHosters():
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl).request()
    pattern = 'data-url="([^"]+)'
    isMatch, aResult = cParser().parse(sHtmlContent, pattern)
    if isMatch:
        sQuality= '720'
        for sUrl in aResult:
            if 'userload' in sUrl:
                continue
            elif sUrl.startswith('//'):
                sUrl = 'https:' + sUrl
            sName = cParser.urlparse(sUrl).split('.')[0].strip()
            if cConfig().isBlockedHoster(sName)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
            hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I][%sp][/I]' % (sName, sQuality), 'quality': sQuality}
            hosters.append(hoster)
        if hosters:
            hosters.append('getHosterUrl')
        return hosters
    if not isMatch:
        cGui().showInfo()
        return

def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30288))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage(): # Suche für die Page Funktion
    params = ParameterHandler()
    sNextPage = params.getValue('sNextPage') # URL mit nächster Seite
    sPageLast = params.getValue('sPageLast') # Anzahl gefundener Seiten
    #sHeading = 'Bitte eine Zahl zwischen 1 und ' + str(sPageLast) + ' wählen.'
    sHeading = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText: return
    if '/genres/' in sNextPage:
        sNextSearchPage = sNextPage.split('page-')[0].strip() + 'page-' + sSearchPageText + '.html'
    else:
        sNextSearchPage = sNextPage.split('page/')[0].strip() + 'page/' + sSearchPageText + '.html'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()