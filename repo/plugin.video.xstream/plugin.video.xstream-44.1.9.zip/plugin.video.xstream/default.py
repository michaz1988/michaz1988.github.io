# -*- coding: utf-8 -*-
# Python 3

from xstream import parseUrl
from os.path import join
from sys import path
import platform

from resources.lib import utils
from resources.lib.config import cConfig
from xbmc import LOGINFO as LOGNOTICE, log


LOGMESSAGE = cConfig().getLocalizedString(30166)
_addonPath_ = utils.addonPath
path.append(join(_addonPath_, 'resources', 'lib'))
path.append(join(_addonPath_, 'resources', 'lib', 'gui'))
path.append(join(_addonPath_, 'resources', 'lib', 'handler'))
path.append(join(_addonPath_, 'resources', 'art', 'sites'))
path.append(join(_addonPath_, 'resources', 'art'))
path.append(join(_addonPath_, 'sites'))
log('-----------------------------------------------------------------------', LOGNOTICE)
log(LOGMESSAGE + ' -> [default]: Start xStream Log, Version %s ' % utils.addon.getAddonInfo('version'), LOGNOTICE)
log(LOGMESSAGE + ' -> [default]: Python-Version: %s' % platform.python_version(), LOGNOTICE)

parseUrl()

