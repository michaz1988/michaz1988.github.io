# -*- coding: utf-8 -*-
# Python 3

import xbmc

LOGDEBUG = xbmc.LOGDEBUG
LOGINFO = xbmc.LOGINFO
LOGWARNING = xbmc.LOGWARNING
LOGERROR = xbmc.LOGERROR


def log(message, level=LOGDEBUG, module=None):
    prefix = '[xStream]'
    if module:
        prefix += ' [%s]' % module
    xbmc.log('%s %s' % (prefix, message), level)

