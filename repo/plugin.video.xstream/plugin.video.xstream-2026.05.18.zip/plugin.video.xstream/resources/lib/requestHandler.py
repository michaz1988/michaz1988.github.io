# -*- coding: utf-8 -*-
# Python 3

from resources.lib.handler.requestHandler import cRequestHandler

