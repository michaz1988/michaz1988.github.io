# -*- coding: utf-8 -*-
# Python 3

import inspect
import json
from urllib.parse import parse_qsl, unquote_plus, urlsplit

from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.handler.ParameterHandler import ParameterHandler


def _caller_site_id():
    for frame in inspect.stack()[2:]:
        module = inspect.getmodule(frame.frame)
        name = getattr(module, '__name__', '')
        if name and not name.startswith('resources.'):
            return name.rsplit('.', 1)[-1]
    return ''


def _params_from_plugin_url(plugin_url):
    params = ParameterHandler()
    if not plugin_url:
        return params, '', ''

    query = plugin_url
    if query.startswith('runPlugin&'):
        query = query[len('runPlugin&'):]
    elif '?' in query:
        query = urlsplit(query).query

    values = dict(parse_qsl(query, keep_blank_values=True))
    function = values.pop('function', '')
    site = values.pop('site', '')
    values.pop('title', None)
    for key, value in values.items():
        params.setParam(key, unquote_plus(value))
    return params, site, function


class navigator:
    def addDirectoryItem(self, name, pluginUrl='', icon='', thumbnail='', **kwargs):
        params, _site, function = _params_from_plugin_url(pluginUrl)
        site_id = _caller_site_id() or _site

        element = cGuiElement(name, site_id, function)
        if icon:
            element.setIcon(icon)
        if thumbnail:
            element.setThumbnail(thumbnail)
        if 'plot' in kwargs and kwargs['plot']:
            element.setDescription(kwargs['plot'])
        if 'desc' in kwargs and kwargs['desc']:
            element.setDescription(kwargs['desc'])
        if 'fanart' in kwargs and kwargs['fanart']:
            element.setFanart(kwargs['fanart'])
        if 'quality' in kwargs and kwargs['quality']:
            element.setQuality(str(kwargs['quality']))

        cGui().addFolder(element, params)

    def xsDirectory(self, items, siteName=None):
        site_id = _caller_site_id()
        gui = cGui()

        for item in items or []:
            title = item.get('title') or item.get('name') or item.get('infoTitle') or ''
            function = item.get('sFunction') or item.get('function') or 'getHosters'
            element = cGuiElement(title, site_id, function)

            poster = item.get('poster') or item.get('thumbnail') or item.get('thumb') or ''
            if poster:
                element.setThumbnail(poster)
            if item.get('fanart'):
                element.setFanart(item.get('fanart'))
            if item.get('plot') or item.get('desc'):
                element.setDescription(item.get('plot') or item.get('desc'))
            if item.get('quality'):
                element.setQuality(str(item.get('quality')))
            if item.get('year'):
                element.setYear(item.get('year'))
            if item.get('season'):
                element.setSeason(item.get('season'))
            if item.get('episode'):
                element.setEpisode(item.get('episode'))
            if item.get('mediatype'):
                element.setMediaType(item.get('mediatype'))
            elif item.get('isTvshow'):
                element.setMediaType('tvshow')
            else:
                element.setMediaType('movie')

            values = dict(item)
            values['meta'] = json.dumps(item)
            element.setItemValues(values)

            params = ParameterHandler()
            for key, value in values.items():
                if value is None:
                    continue
                if isinstance(value, (dict, list)):
                    value = json.dumps(value)
                params.setParam(key, value)

            is_folder = bool(item.get('isTvshow')) or function not in ('getHosters', 'showHosters', 'showHosters_1')
            gui.addFolder(element, params, bIsFolder=is_folder)

    def _endDirectory(self, *args, **kwargs):
        success = True
        if args and isinstance(args[0], bool):
            success = args[0]
        cGui().setEndOfDirectory(success)

