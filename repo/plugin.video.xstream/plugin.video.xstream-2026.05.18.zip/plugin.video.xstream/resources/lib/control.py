# -*- coding: utf-8 -*-
# Python 3

import xbmc
import xbmcgui

from urllib.parse import quote, quote_plus, unquote, unquote_plus

from resources.lib.config import cConfig


progressDialog = xbmcgui.DialogProgress()
unescape = unquote_plus
execute = xbmc.executebuiltin


def getSetting(name, default=''):
    return cConfig().getSetting(name, default)


def setSetting(name, value):
    return cConfig().setSetting(name, value)

