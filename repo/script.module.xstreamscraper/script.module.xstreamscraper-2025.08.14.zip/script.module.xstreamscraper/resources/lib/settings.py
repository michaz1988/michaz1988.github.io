
def init():
	global aDirectory
	global urlparams
	global collectMode
	global skip
	aDirectory = []
	urlparams = {}
	collectMode = False
	skip = "Ok"