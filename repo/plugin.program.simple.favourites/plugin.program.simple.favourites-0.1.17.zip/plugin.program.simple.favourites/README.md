# plugin.simple.favourites

Simple Favourites
